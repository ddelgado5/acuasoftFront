$(() => {
    $('#leftPanelLink').hide();

    sessionStorage.setItem('email', 'hector@mail.co');
    sessionStorage.setItem('clave', 'h3ct0r');
});

function iniciarSesion(enlace) {

    let email = $('#email').val();
    let clave = $('#clave').val();

    if (sessionStorage.getItem('email') != email || sessionStorage.getItem('clave') != clave) {
        alert('Credenciales inválidas');
        return;
    }

    location.href = '/pages/main.html';
}
